# 專案工作追蹤

本專案使用已確認的 docs/SDD-v0.1.md 與 docs/VALIDATION.md 追蹤範圍及驗收；目前没有外部 issue tracker。

