"""Original pixel art by 中揚資訊. Artwork and drawing patterns: CC BY 4.0.
Generator infrastructure: MIT. No external images or generative-image inputs.
"""
from pathlib import Path
from PIL import Image, ImageDraw
import random

OUT = Path(__file__).resolve().parents[1] / "public/art"
OUT.mkdir(parents=True, exist_ok=True)
INK = "#173d39"

def sheet(name, width, height, frames, draw):
    image = Image.new("RGBA", (width * frames, height))
    for frame in range(frames):
        tile = Image.new("RGBA", (width, height))
        draw(ImageDraw.Draw(tile), frame)
        image.paste(tile, (frame * width, 0))
    image.save(OUT / name)

def traveler(d, f):
    dy = 1 if f in (1, 3) else 0
    def r(box, color): d.rectangle((box[0], box[1]+dy, box[2], box[3]+dy), fill=color)
    r((3, 14, 8, 25), "#355f54")
    r((4, 13, 7, 21), "#8ab29b")
    r((8, 11, 18, 24), INK)
    r((9, 12, 17, 23), "#ee894d")
    r((10, 13, 12, 22), "#ffc778")
    r((15, 15, 18, 20), "#fac599")
    r((7, 4, 18, 12), INK)
    r((9, 5, 18, 11), "#fac599")
    r((16, 7, 17, 8), INK)
    r((6, 1, 17, 5), INK)
    r((7, 2, 16, 4), "#f1c86e")
    r((5, 5, 20, 6), "#f1c86e")
    r((10, 24, 12, 28), "#335c59")
    r((15, 24, 17, 28), "#335c59")
    r((9 if f != 2 else 6, 29, 13, 30), INK)
    r((15, 29 if f != 3 else 27, 19, 30 if f != 3 else 28), INK)
    if f == 4:
        r((18, 15, 23, 17), "#fac599")
        r((21, 10, 23, 13), "#ffd877")
    if f == 5: r((10, 16, 16, 19), "#f3e4ca")
sheet("traveler.png", 24, 32, 6, traveler)

def monster(d, f, kind):
    c = ["#668d67", "#c27568", "#6e80ad"][kind]
    y = 3 + f
    d.rectangle((3, y+4, 20, 21), fill=INK)
    d.rectangle((5, y+2, 18, 19), fill=c)
    d.rectangle((7, y+5, 10, y+8), fill="#fff2d8")
    d.rectangle((14, y+5, 17, y+8), fill="#fff2d8")
    d.rectangle((9, y+7, 10, y+8), fill=INK)
    d.rectangle((14, y+7, 15, y+8), fill=INK)
    d.rectangle((8, y+12, 16, y+13), fill=INK)
    d.rectangle((4, 21, 8, 23), fill=INK)
    d.rectangle((16, 21, 20, 23), fill=INK)
    if kind == 1: d.rectangle((19, 9, 23, 12), fill="#ffc777")
    if kind == 2:
        d.rectangle((0, y+8, 4, y+13), fill=c)
        d.rectangle((20, y+8, 23, y+13), fill=c)
for k in range(3):
    sheet(f"enemy-{k}.png", 24, 24, 2, lambda d, f, k=k: monster(d, f, k))

def boss(d, f):
    d.rectangle((5, 11, 43, 43), fill=INK)
    d.rectangle((8, 13, 40, 39), fill="#655e85")
    d.rectangle((12, 5, 36, 16), fill=INK)
    d.rectangle((14, 7, 34, 15), fill="#dca05c")
    d.rectangle((19, 2, 29, 9), fill="#ffe5a1")
    for x in (14, 29):
        d.rectangle((x, 19, x+6, 24), fill="#fff2d8")
        d.rectangle((x+2, 22, x+4, 24), fill=INK)
    d.rectangle((17, 29+f, 32, 31+f), fill=INK)
    d.rectangle((3, 25, 10, 38), fill="#8d819d")
    d.rectangle((38, 25, 45, 38), fill="#8d819d")
    d.rectangle((9, 40, 17, 47), fill=INK)
    d.rectangle((31, 40, 39, 47), fill=INK)
sheet("boss.png", 48, 48, 2, boss)

def food(d, f):
    if f == 0:
        d.rectangle((2, 5, 14, 14), fill=INK)
        d.rectangle((3, 6, 13, 12), fill="#edc374")
        for x,y in [(5,8),(10,7),(8,10)]: d.rectangle((x,y,x+1,y+1), fill="#bd8d4d")
        d.rectangle((4, 2, 6, 4), fill="#8aaf6d")
        d.rectangle((10, 0, 12, 3), fill="#8aaf6d")
    elif f == 1:
        d.ellipse((2, 2, 14, 15), fill=INK)
        d.ellipse((3, 3, 13, 14), fill="#95804e")
        d.ellipse((5, 5, 12, 12), fill="#47544b")
        d.ellipse((7, 6, 11, 10), fill="#d5b66b")
    else:
        d.rectangle((7, 0, 8, 15), fill="#e3b766")
        d.rectangle((3, 2, 12, 11), fill=INK)
        d.rectangle((4, 3, 11, 10), fill="#5e3b31")
        for x,y in [(5,4),(9,6),(6,8)]: d.rectangle((x,y,x+1,y+1), fill="#cfb886")
sheet("foods.png", 16, 16, 3, food)

def icon(d, f):
    if f == 0:
        d.rectangle((2, 1, 15, 18), fill=INK)
        d.rectangle((4, 3, 13, 16), fill="#fce8bd")
        d.rectangle((6, 5, 11, 10), fill="#dd925e")
        d.rectangle((6, 13, 11, 13), fill="#6b8879")
    elif f == 1:
        d.rectangle((3, 12, 15, 17), fill=INK)
        d.rectangle((6, 6, 12, 12), fill="#d39355")
        d.rectangle((4, 3, 14, 7), fill="#edc374")
    else:
        d.rectangle((5, 1, 6, 19), fill=INK)
        d.rectangle((7, 2, 16, 9), fill="#e48454")
        d.rectangle((8, 3, 14, 7), fill="#ffd489")
sheet("icons.png", 20, 20, 3, icon)

def background(level):
    rng = random.Random(level)
    im = Image.new("RGB", (960, 450), "#edeee1" if level != 2 else "#dfede6")
    d = ImageDraw.Draw(im)
    d.rectangle((0, 245, 960, 450), fill=["#c4ceab","#a5b9a1","#92b8ad"][level])
    for x in range(30, 960, 160):
        d.rectangle((x, 65, x+58, 77), fill="#fff9e8")
        d.rectangle((x+15, 55, x+44, 65), fill="#fff9e8")
    if level == 1:
        for x in range(-80, 1000, 220):
            d.polygon([(x,300),(x+170,110+rng.randrange(40)),(x+330,300)], fill="#8fa799")
        for i,x in enumerate(range(0,960,85)):
            y=210+(i%4)*20
            d.rectangle((x,y,x+74,365),fill=["#aa8770","#b69776","#8b9984"][i%3])
            d.rectangle((x-4,y-8,x+78,y),fill="#48665b")
            for yy in range(y+17,350,33):
                for xx in range(x+12,x+64,26): d.rectangle((xx,yy,xx+10,yy+15),fill="#f4d89e")
            d.rectangle((x+62,y+7,x+67,y+15),fill="#de885d")
    elif level == 0:
        for i,x in enumerate(range(0,960,96)):
            y=200+(i%3)*22
            d.rectangle((x,y,x+86,360),fill=["#c5a689","#b69c84","#c9bca0"][i%3])
            d.rectangle((x-3,y-7,x+88,y),fill="#55796a")
            for xx in range(x+9,x+81,25):
                d.rectangle((xx,y+22,xx+14,y+45),fill="#698576")
                d.rectangle((xx,315,xx+14,360),fill="#7d8a73")
            d.rectangle((x+3,285,x+82,300),fill="#d9956c")
        d.rectangle((380,235,555,275),fill="#b45f4b")
        d.polygon([(365,235),(405,215),(530,215),(570,235)], fill="#4a6859")
        d.rectangle((415,187,520,218),fill="#be7559")
        d.polygon([(396,187),(435,167),(500,167),(539,187)],fill="#4a6859")
    else:
        d.rectangle((0,278,960,370),fill="#82afa7")
        for y in range(290,360,16):
            for x in range(y%80,960,110): d.rectangle((x,y,x+48,y+2),fill="#c0d6c0")
        for i,x in enumerate(range(0,960,120)):
            if i<4:
                d.rectangle((x,235,x+105,315),fill="#c5af94")
                d.polygon([(x-5,235),(x+50,208),(x+110,235)],fill="#6a8978")
                d.rectangle((x+35,270,x+67,315),fill="#66867d")
            else:
                d.rectangle((x+50,185,x+53,300),fill="#557a73")
                d.polygon([(x+55,190),(x+55,265),(x+105,265)],fill="#faf3d8")
                d.polygon([(x+7,305),(x+105,305),(x+84,323),(x+22,323)],fill="#b8795d")
    im.save(OUT/f"background-{level}.png")
for level in range(3): background(level)

# Distinct local-inspired scene sections; all shapes remain original CC BY artwork.
for level in range(3):
    base = Image.open(OUT/f"background-{level}.png")
    for section in range(3):
        im = base.copy(); d = ImageDraw.Draw(im)
        if section == 1 and level in (0, 2):
            d.rectangle((0,195,960,365),fill="#b5b49a")
            for x in range(0,960,120):
                d.rectangle((x,220,x+110,365),fill="#b78768" if level==0 else "#c8ad89")
                d.rectangle((x-3,213,x+113,220),fill="#657e68")
                for y in range(245,360,14):
                    d.line((x,y,x+110,y),fill="#c39a7b")
                for xx in (x+14,x+64):
                    d.rectangle((xx,296,xx+30,365),fill="#577769")
                    d.rectangle((xx-3,290,xx+33,297),fill="#e0c19b")
                    d.rectangle((xx+4,252,xx+23,273),fill="#688b7c")
        if section == 2 and level == 0:
            for x in range(0,960,130):
                d.rectangle((x+6,301,x+113,367),fill="#9a7860")
                d.rectangle((x,282,x+120,299),fill="#dc9367")
                for xx in range(x+5,x+120,20):d.rectangle((xx,282,xx+9,299),fill="#f4d4a0")
                d.rectangle((x+30,325,x+88,345),fill="#e4c591")
        if section == 2 and level == 1:
            d.rectangle((0,210,960,367),fill="#9aada0")
            for x in range(40,960,260):
                d.rectangle((x,225,x+80,355),fill="#637e73")
                d.rectangle((x+12,232,x+68,242),fill="#cfbb8e")
                d.line((x+5,248,x+75,350),fill="#3c5c54",width=5)
                d.line((x+75,248,x+5,350),fill="#3c5c54",width=5)
                d.rectangle((x+100,320,x+170,350),fill="#765f4f")
                d.polygon([(x+101,320),(x+135,303),(x+169,320)],fill="#405e56")
                d.rectangle((x+107,350,x+118,359),fill="#31524c")
                d.rectangle((x+153,350,x+164,359),fill="#31524c")
            d.rectangle((0,365,960,368),fill="#688576")
        if section == 1 and level == 1:
            for x in range(0,960,110):
                d.rectangle((x+15,282,x+96,293),fill="#d6b798")
                d.rectangle((x+40,266,x+96,280),fill="#d6b798")
                d.rectangle((x+65,252,x+96,264),fill="#d6b798")
        im.save(OUT/f"background-{level}-section-{section}.png")

def platform(d,f):
    d.rectangle((0,0,31,31),fill="#577966")
    d.rectangle((0,0,31,6),fill="#a9ba82")
    d.rectangle((0,7,31,10),fill="#708b69")
    for x,y in [(5,16),(22,20),(11,27)]: d.rectangle((x,y,x+4,y+2),fill="#456355")
sheet("tile.png",32,32,1,platform)

(OUT/"favicon.svg").write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#173d39"/><path d="M20 4h4v8h-4v8h-4v8h-8v-8h4v-8h4V8h4z" fill="#f3cb78"/></svg>')
print("Original CC BY 4.0 artwork generated:", len(list(OUT.iterdir())), "files")
