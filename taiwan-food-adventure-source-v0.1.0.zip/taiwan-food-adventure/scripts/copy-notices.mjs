import { copyFile } from 'node:fs/promises';
for (const name of ['LICENSE', 'ART-LICENSE.md', 'THIRD-PARTY-NOTICES.txt']) {
  await copyFile(name, `dist/${name}`);
}
