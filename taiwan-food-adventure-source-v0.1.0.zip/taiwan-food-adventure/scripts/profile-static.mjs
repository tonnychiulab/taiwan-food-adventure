import {chromium} from 'playwright';
import {createServer} from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {gzipSync} from 'node:zlib';
const mime={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
const root=path.resolve('dist');
const server=createServer(async(req,res)=>{
 try{let url=decodeURIComponent((req.url??'/').split('?')[0]);let file=path.resolve(root,url==='/'?'index.html':'.'+url);if(!file.startsWith(root+path.sep))throw Error('Invalid path');
 const data=await fs.readFile(file),ext=path.extname(file);res.setHeader('Content-Type',mime[ext]??'text/plain');res.setHeader('Cache-Control','no-store');
 if(['.js','.css','.html','.svg'].includes(ext)){res.setHeader('Content-Encoding','gzip');res.end(gzipSync(data));}else res.end(data);
 }catch{res.statusCode=404;res.end('Not found');}
});
await new Promise(resolve=>server.listen(5181,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{}),args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
try{
 const page=await browser.newPage({viewport:{width:1280,height:800}});
 const session=await page.context().newCDPSession(page);await session.send('Network.enable');await session.send('Network.setCacheDisabled',{cacheDisabled:true});
 await session.send('Network.emulateNetworkConditions',{offline:false,latency:100,downloadThroughput:20e6/8,uploadThroughput:20e6/8});
 let bytes=0;session.on('Network.loadingFinished',event=>bytes+=event.encodedDataLength);
 const started=Date.now();await page.goto('http://127.0.0.1:5181/');
 await page.locator('[data-start="wanhua"]').click();await page.locator('[data-action="resume"]').first().click();
 const coldStartMs=Date.now()-started,firstPlayBytes=bytes;
 const frameStats=await page.evaluate(()=>new Promise(resolve=>{
  let start=performance.now(),last=start,samples=[];
  const tick=now=>{samples.push(now-last);last=now;if(now-start<10000)requestAnimationFrame(tick);else{samples.sort((a,b)=>a-b);resolve({durationMs:now-start,frames:samples.length,medianMs:samples[Math.floor(samples.length*.5)],p95Ms:samples[Math.floor(samples.length*.95)],within33ms:samples.filter(n=>n<=33).length/samples.length});}};requestAnimationFrame(tick);
 }));
 const result={date:new Date().toISOString(),browser:browser.version(),renderer:'Headless Chromium / software SwiftShader, viewport 1280×800; idle first segment; NOT physical phone acceptance.',network:'20 Mbps download / 100 ms emulated latency / cold cache / text assets gzipped',coldStartMs,firstPlayBytes,frameStats,limitations:['Ten-second idle frame sample is not the five-minute busy-scene benchmark.','No physical Android/iPhone or fifteen-minute thermal/memory test.','Synthetic network simulation is not a guarantee for live hosting.']};
 await fs.writeFile('artifacts/performance-report.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}finally{await browser.close();server.close();}
