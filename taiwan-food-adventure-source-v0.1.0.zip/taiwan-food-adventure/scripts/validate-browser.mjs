import {chromium} from 'playwright';
import {createServer} from 'vite';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';

const server=await createServer({server:{host:'127.0.0.1',port:5175}});
server.middlewares.use('/qa-project',async(req,res,next)=>{
 try{
  const pathname=decodeURIComponent((req.url??'/').split('?')[0]);
  const file=path.resolve('dist',pathname==='/'?'index.html':'.'+pathname);
  if(!file.startsWith(path.resolve('dist')+path.sep)){res.statusCode=403;res.end();return;}
  const data=await fs.readFile(file);
  const ext=path.extname(file);res.setHeader('Content-Type',({'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'})[ext]??'application/octet-stream');res.end(data);
 }catch{next();}
});
await server.listen();
const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM_PATH?{executablePath:process.env.CHROMIUM_PATH}:{}),args:['--no-sandbox','--disable-dev-shm-usage','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const report={date:new Date().toISOString(),checks:[],errors:[],mode:'Desktop headless Chromium; isolated fixtures reposition characters for combat/collection/completion. Not a full human playthrough or physical phone test.'};
const record=(name,details)=>{report.checks.push({name,details});console.log('PASS',name,details??'');};
const url='http://127.0.0.1:5175';
async function attach(page){page.on('pageerror',e=>report.errors.push(e.message));page.on('dialog',d=>d.accept());await page.evaluate(async()=>{window.__qa=(await import('/src/main.ts')).validationContext;});}
async function start(page,id){
 await page.locator('[data-start="'+id+'"]').first().click();
 await page.waitForFunction(()=>window.__qa().loaded,null,{timeout:15000});
 const overlay=page.locator('#overlay');
 if(await overlay.isVisible()){
  const resume=overlay.locator('[data-action="resume"]');
  if(await resume.count())await resume.first().click();
 }
 await page.waitForTimeout(250);
}
try{
 const context=await browser.newContext({viewport:{width:1360,height:900}});
 const page=await context.newPage();await page.goto(url);await attach(page);
 await page.screenshot({path:'artifacts/home.png',fullPage:true});
 assert.equal(await page.locator('[data-start]').count(),3);record('three selectable regions');
 await start(page,'wanhua');
 const before=await page.evaluate(()=>window.__qa().scene.player.x);
 await page.keyboard.down('ArrowRight');await page.waitForFunction(x=>window.__qa().scene.player.x>x+50,before,{timeout:6000});await page.keyboard.up('ArrowRight');
 const after=await page.evaluate(()=>window.__qa().scene.player.x);assert(after>before+40);
 const ground=await page.evaluate(()=>window.__qa().scene.player.y);
 await page.keyboard.down('Space');await page.waitForFunction(y=>window.__qa().scene.player.y<y-25,ground,{timeout:3000});await page.keyboard.up('Space');
 const air=await page.evaluate(()=>window.__qa().scene.player.y);assert(air<ground-20);
 await page.waitForTimeout(750);record('keyboard movement and actual jump',{distance:Math.round(after-before),rise:Math.round(ground-air)});
 await page.evaluate(()=>window.__qa().scene.player.setPosition(820,355).setVelocity(0,0));await page.waitForTimeout(250);
 await page.keyboard.down('ArrowRight');await page.keyboard.down('Space');await page.waitForTimeout(180);await page.keyboard.up('Space');
 await page.waitForFunction(()=>window.__qa().scene.player.x>1000,null,{timeout:5000});await page.keyboard.up('ArrowRight');
 record('actual jump clears the first gap');

 await page.keyboard.press('Escape');assert(await page.locator('.pause-dialog').isVisible());
 const px=await page.evaluate(()=>window.__qa().scene.player.x);await page.waitForTimeout(180);
 assert.equal(await page.evaluate(()=>window.__qa().scene.player.x),px);await page.locator('[data-action="resume"]').click();record('pause freezes physics and resumes');
 await page.screenshot({path:'artifacts/game.png'});
 for(const [index,id] of ['wanhua','ruifang','magong'].entries()){
  if(index){await page.locator('.finish [data-action="leave"]').click();await start(page,id);}
  const hpBefore=await page.evaluate(()=>{const c=window.__qa(),s=c.scene;const enemy=s.enemies.find(e=>!e.boss&&e.kind===0);
   s.player.setPosition(enemy.sprite.x-(s.level.weapon==='egg'?220:70),enemy.sprite.y-5).setVelocity(0,0);s.facing=1;s.invulnerableUntil=1e9;enemy.stunUntil=1e9;return enemy.hp;});
  await page.waitForTimeout(250);await page.keyboard.down('KeyJ');await page.waitForFunction(()=>window.__qa().scene.enemies.find(e=>!e.boss&&e.kind===0).hp<2,null,{timeout:5000});await page.keyboard.up('KeyJ');
  const enemyAfter=await page.evaluate(()=>window.__qa().scene.enemies.find(e=>!e.boss&&e.kind===0).hp);
  assert(enemyAfter<hpBefore,id+' weapon must hit');record(id+' weapon hits',{hpBefore,enemyAfter});
  await page.evaluate(()=>{const s=window.__qa().scene;s.player.setPosition(4885,355).setVelocity(0,0);});
  await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>window.__qa().scene.checkpoint),4885);
  await page.evaluate(()=>{window.__qa().scene.player.setPosition(5400,540).setVelocity(0,0);});
  await page.waitForTimeout(200);assert(Math.abs(await page.evaluate(()=>window.__qa().scene.player.x)-4885)<10);
  record(id+' checkpoint and fall recovery');
  for(let n=0;n<3;n++){
   await page.evaluate(n=>{const s=window.__qa().scene;const item=s.pickups.getChildren()[n];s.player.setPosition(item.body.center.x,item.body.center.y).setVelocity(0,0);},n);
   await page.waitForTimeout(180);
  }
  const count=await page.evaluate(()=>window.__qa().store.data.cards.length);assert.equal(count,(index+1)*3);record(id+' collects all three cards');
  if(id==='magong'){
   await page.evaluate(()=>{const s=window.__qa().scene;s.player.setPosition(s.boss.sprite.x-70,s.boss.sprite.y).setVelocity(0,0);s.invulnerableUntil=1e9;s.facing=1;s.boss.stunUntil=1e9;});
   // Keep within melee range while the isolated boss fixture receives real attack input.
   await page.keyboard.down('KeyJ');
   for(let i=0;i<12;i++){await page.evaluate(()=>{const s=window.__qa().scene;if(s.boss.hp>0)s.player.setPosition(s.boss.sprite.x-65,s.boss.sprite.y).setVelocity(0,0);});await page.waitForTimeout(280);}
   await page.keyboard.up('KeyJ');assert((await page.evaluate(()=>window.__qa().scene.boss.hp))<=0);record('boss defeated through melee attack');
  }
  await page.evaluate(()=>window.__qa().scene.player.setPosition(14300,350).setVelocity(0,0));await page.waitForTimeout(200);
  assert(await page.locator('.finish').isVisible());assert.equal(await page.evaluate(()=>window.__qa().store.data.stamps.length),index+1);
  record(id+' completes and saves stamp');
 }
 await page.locator('.finish [data-view="passport"]').click();
 assert.equal(await page.locator('.collection.found').count(),9);
 await page.screenshot({path:'artifacts/passport.png',fullPage:true});
 await page.reload();await attach(page);assert.equal(await page.evaluate(()=>window.__qa().store.data.cards.length),9);record('nine cards and three stamps survive reload');
 await page.locator('[data-view="settings"]').first().click();await page.locator('[data-bind="jump"]').click();await page.keyboard.press('KeyK');
 assert.equal(await page.evaluate(()=>window.__qa().store.data.settings.keys.jump[0]),'KeyK');record('keyboard rebinding');
 await context.close();

 const missingContext=await browser.newContext({viewport:{width:1200,height:800}});
 const missing=await missingContext.newPage();await missing.route('**/art/foods.png',r=>r.abort());
 await missing.goto(url);await attach(missing);await missing.locator('[data-start="wanhua"]').click();await missing.waitForTimeout(1400);
 assert(await missing.locator('#overlay').innerText().then(s=>s.includes('沒有載入完成')));assert.equal(await missing.evaluate(()=>window.__qa().loaded),false);
 await missing.unroute('**/art/foods.png');await missing.locator('[data-action="restart"]').click();await missing.waitForFunction(()=>window.__qa().loaded);
 record('missing asset stays on error screen and retry recovers');await missingContext.close();


 const slowContext=await browser.newContext({viewport:{width:1200,height:800}}),slow=await slowContext.newPage();
 let firstBackground=true;
 await slow.route('**/background-0-section-0.png',async route=>{if(firstBackground){firstBackground=false;await new Promise(resolve=>setTimeout(resolve,900));}try{await route.continue();}catch{}});
 await slow.goto(url);await attach(slow);await slow.locator('[data-start="wanhua"]').click();
 await slow.waitForTimeout(100);await slow.locator('#overlay [data-action="leave"]').click();
 await start(slow,'wanhua');assert.equal(await slow.evaluate(()=>window.__qa().paused),false);
 assert(await slow.locator('#overlay').isHidden());record('cancel slow loading and restart without stale callbacks');
 await slowContext.close();

 const phoneContext=await browser.newContext({viewport:{width:844,height:390},isMobile:true,hasTouch:true});
 const phone=await phoneContext.newPage();await phone.goto(url);await attach(phone);await start(phone,'wanhua');
 const x=await phone.evaluate(()=>window.__qa().scene.player.x);
 const right=await phone.locator('[data-touch="right"]').boundingBox(),jump=await phone.locator('[data-touch="jump"]').boundingBox();
 assert(right&&jump);
 const cdp=await phoneContext.newCDPSession(phone);
 await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:right.x+right.width/2,y:right.y+right.height/2,id:1},{x:jump.x+jump.width/2,y:jump.y+jump.height/2,id:2}]});
 await phone.waitForTimeout(230);
 const touchResult=await phone.evaluate(()=>({x:window.__qa().scene.player.x,y:window.__qa().scene.player.y}));
 await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
 assert(touchResult.x>x+10&&touchResult.y<330);assert.equal(await phone.evaluate(()=>scrollY),0);
 record('two-finger movement+jump without scroll',touchResult);
 await phone.waitForTimeout(650);await phone.screenshot({path:'artifacts/mobile-landscape.png'});
 await phone.setViewportSize({width:390,height:844});await phone.waitForTimeout(200);
 assert((await phone.locator('#overlay').innerText()).includes('轉橫向'));record('portrait rotation pauses gameplay');
 await phoneContext.close();

 const prodContext=await browser.newContext({viewport:{width:1200,height:800}});
 const prod=await prodContext.newPage();let notFound=[];prod.on('response',r=>{if(r.status()>=400)notFound.push(r.url())});prod.on('pageerror',e=>report.errors.push(e.message));
 await prod.goto(url+'/qa-project/');await prod.locator('[data-start="wanhua"]').click();await prod.locator('[data-action="resume"]').first().waitFor();await prod.locator('[data-action="resume"]').first().click();await prod.waitForTimeout(500);
 assert.equal(notFound.length,0);assert(await prod.locator('#stage canvas').count());record('production build works under project subdirectory',{notFound});
 await prodContext.close();
 assert.equal(report.errors.length,0,report.errors.join('\n'));
}catch(error){report.errors.push(String(error));console.error(error);process.exitCode=1;}
finally{await fs.writeFile('artifacts/browser-report.json',JSON.stringify(report,null,2));await browser.close();await server.close();}
