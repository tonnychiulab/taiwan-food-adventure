# 台灣小吃冒險：環島護照

v0.1.0 試玩版 · 製作團隊：中揚資訊 · https://joyyoung.ai/

以 Phaser 3.90.0、TypeScript 製作的純靜態像素平台遊戲。
三關為萬華（臭豆腐）、瑞芳（皮蛋）、馬公（豬血糕與頭目），有九張特色卡、三枚印章、本機存檔、鍵位設定與多點觸控。

## 開發與建置

需要 Node.js 22 或 24，npm，以及首次安裝時的網路。

```sh
npm ci
npm run dev
npm run typecheck
npm test
npm run build
npm run preview
```

若環境不允許列出網路介面，啟動時加上 --host 127.0.0.1。
dist/ 是靜態部署目錄，不能只把 src/ 上傳。不要直接雙擊 index.html，以 HTTP 靜態伺服器或網站開啟。

## 操作

- 左右方向鍵或 A／D 移動，空白鍵跳躍，J／Z 攻擊，Esc 暫停。
- 攻擊可按住。手機轉橫向，使用左右、跳躍與攻擊按鈕。
- 鍵位與音量可在設定中更改；省效能模式關閉背景移動。
- 三格生命、不限次重試；檢查點限當次關卡。
- 收藏與通關即時保存；退出再進關從起點開始。
- 換網址、瀏覽器或裝置不會同步；清除網站資料可能失去進度。

## 雙平台部署

同一 dist/ 可部署到 Cloudflare DROP 與 GitHub Pages。
資源採相對 base，遊戲內不使用依賴伺服器重寫的路徑。

Cloudflare DROP：https://www.cloudflare.com/drop/
上傳 dist/ 資料夾，或解開後頂層有 index.html 的部署 ZIP。官方目前要求臨時部署在 60 分鐘內認領，正式使用前確認認領與網址。
認領連結不得放進公開儲存庫。

GitHub Pages：將本專案推送到 GitHub，在儲存庫 Settings → Pages 選 GitHub Actions，再使用附帶的工作流程。預設監聽 main，其他分支自行調整。
尚未公開部署。已用本機 /qa-project/ 路徑驗證相對資源，正式上線後仍需檢查網站。

## 素材重建

安裝 Pillow 後：

```sh
python3 scripts/create-art.py
```

所有既有圖像已包含在 public/art/，一般建置不必安裝 Python。

## 驗收

規格見 docs/SDD-v0.1.md，實際結果見 docs/VALIDATION.md。
自動化測試不能替代 iPhone／Android 實機、五位新手試玩與長時間效能驗收。
程式採 MIT；原創美術與音樂設計採 CC BY 4.0。見 LICENSE、ART-LICENSE.md、THIRD-PARTY-NOTICES.txt。


## 瀏覽器回歸與效能抽樣

```sh
npx playwright install chromium
npm run test:browser
npm run build
npm run profile
```

測試腳本自行啟動本機伺服器；若使用既有 Chromium，可設定 CHROMIUM_PATH。
效能腳本模擬 20 Mbps／100 ms 冷快取並抽樣十秒，不代表手機實機或長時間驗收。
