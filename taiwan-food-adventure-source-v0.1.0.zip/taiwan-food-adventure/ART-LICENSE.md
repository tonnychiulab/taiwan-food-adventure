# 原創素材授權與來源

製作：中揚資訊，2026。https://joyyoung.ai/

public/art/ 的像素圖像、scripts/create-art.py 內的圖像設計，以及 src/audio.ts 內的音樂旋律與音效設計，以 Creative Commons Attribution 4.0 International（CC BY 4.0）提供。

授權全文：https://creativecommons.org/licenses/by/4.0/legalcode
摘要：https://creativecommons.org/licenses/by/4.0/

可依授權商用、修改與散布，須合理署名、提供授權連結，並標示修改。
建議署名：「像素美術／音樂：中揚資訊，CC BY 4.0；修改：〈你的名稱與說明〉」。

| 素材 | 檔案 | 來源與用途 |
|---|---|---|
| 小旅角色六幀 | traveler.png | 原創，待機、跑步、跳躍、攻擊、受傷 |
| 三類怪物 | enemy-0.png、enemy-1.png、enemy-2.png | 原創虛構角色 |
| 印章怪物 | boss.png | 原創虛構頭目 |
| 台灣小吃 | foods.png | 原創臭豆腐、皮蛋、豬血糕 |
| 護照／印章／旗幟 | icons.png | 原創 |
| 萬華／瑞芳／馬公背景 | background-0.png 至 background-2.png | 原創地方取景，非街道實測圖 |
| 九個地方分段背景 | background-*-section-*.png | 原創，各關三個地方場景 |
| 平台地面 | tile.png | 原創 |
| 網站圖示 | favicon.svg | 原創 |
| 示意地圖 | src/main.ts 的 islandMap SVG | 原創，不作導航 |
| 音樂與音效 | src/audio.ts | 原創短旋律與瀏覽器合成音效 |

沒有使用外部照片、外部遊戲圖像或 AI 生成圖像。地方事實由官方網頁查核，來源清單見 docs/SDD-v0.1.md 與 src/content.ts。
網站與選單使用裝置系統字型，沒有重新散布外部字型。
生成工具的程式邏輯、音訊播放邏輯與其餘原創程式採 MIT；上述作品設計採 CC BY 4.0。作品名稱、團隊標誌與商標不包含在素材授權內。

