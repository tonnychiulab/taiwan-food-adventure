import { test } from 'node:test';
import assert from 'node:assert/strict';
import { SaveStore, SAVE_KEY } from '../src/storage.ts';
class MemoryStorage {
 values = new Map<string,string>();
 getItem(key:string){return this.values.get(key)??null;}
 setItem(key:string,value:string){this.values.set(key,value);}
 removeItem(key:string){this.values.delete(key);}
}
test('collectibles survive reload, deduplicate, and stay in the project namespace',()=>{
 const memory=new MemoryStorage(); memory.setItem('another-game','safe');
 const first=new SaveStore(memory);
 first.collect('wanhua-temple'); first.collect('wanhua-temple'); first.complete('wanhua');
 const second=new SaveStore(memory);
 assert.deepEqual(second.data.cards,['wanhua-temple']); assert.deepEqual(second.data.stamps,['wanhua']);
 assert.equal(memory.getItem('another-game'),'safe');
});
test('blocked storage retains progress in memory and reports the failure',()=>{
 const blocked={getItem(){throw new Error('blocked')},setItem(){throw new Error('blocked')},removeItem(){throw new Error('blocked')}};
 const store=new SaveStore(blocked); store.collect('magong-sea');
 assert.equal(store.available,false); assert.equal(store.data.cards.length,1);
});
test('damaged or future-schema data is not silently overwritten',()=>{
 const memory=new MemoryStorage(); const raw='{"schema":500,"cards":["unknown"]}'; memory.setItem(SAVE_KEY,raw);
 const store=new SaveStore(memory); store.collect('wanhua-temple');
 assert.equal(store.available,false); assert.equal(memory.getItem(SAVE_KEY),raw);
 store.reset(); assert.equal(store.available,true); assert.equal(store.data.cards.length,0);
});
test('invalid types and unknown content are rejected',()=>{
 const memory=new MemoryStorage();
 memory.setItem(SAVE_KEY,JSON.stringify({schema:1,cards:['fake'],stamps:[],settings:{}}));
 const store=new SaveStore(memory); assert.equal(store.available,false);
});
test('settings persist and hostile values cannot invalidate controls',()=>{
 const memory=new MemoryStorage(); const store=new SaveStore(memory);
 store.updateSettings({music:0.3,touchSize:1.2}); const reload=new SaveStore(memory);
 assert.equal(reload.data.settings.music,0.3); assert.equal(reload.data.settings.touchSize,1.2);
});

