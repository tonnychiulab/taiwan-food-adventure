import type {Action,Settings} from './storage';
export class Controls{
 enabled=false; private keys=new Set<string>();private pointers=new Map<number,Action>();private previousJump=false;
 capture:((code:string)=>void)|null=null; onPause:()=>void=()=>{};
 constructor(private settings:()=>Settings){
  window.addEventListener('keydown',e=>{
   if(this.capture){e.preventDefault();if(!e.repeat)this.capture(e.code);return;}
   if(!this.enabled)return;
   if(e.code==='Escape'){e.preventDefault();if(!e.repeat)this.onPause();return;}
   if(Object.values(this.settings().keys).some(codes=>codes.includes(e.code))){e.preventDefault();this.keys.add(e.code);}
  });
  window.addEventListener('keyup',e=>this.keys.delete(e.code));
  window.addEventListener('blur',()=>this.clear());
 }
 held(action:Action){return this.enabled&&(this.settings().keys[action].some(c=>this.keys.has(c))||[...this.pointers.values()].includes(action));}
 jumpPressed(){const down=this.held('jump');const edge=down&&!this.previousJump;this.previousJump=down;return edge;}
 clear(){this.keys.clear();this.pointers.clear();this.previousJump=false;document.querySelectorAll('.touch.pressed').forEach(b=>b.classList.remove('pressed'));}
 bindTouch(button:HTMLElement,action:Action){
  button.addEventListener('pointerdown',e=>{e.preventDefault();if(!this.enabled)return;button.setPointerCapture(e.pointerId);this.pointers.set(e.pointerId,action);button.classList.add('pressed');});
  const release=(e:PointerEvent)=>{this.pointers.delete(e.pointerId);button.classList.remove('pressed');};
  button.addEventListener('pointerup',release);button.addEventListener('pointercancel',release);button.addEventListener('lostpointercapture',release);
 }
}

