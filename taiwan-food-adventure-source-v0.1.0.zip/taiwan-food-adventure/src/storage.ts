import { ALL_CARD_IDS, LEVEL_IDS, type LevelId } from './content';
export const SAVE_KEY='joyyoung.taiwan-food-adventure.v1';
export type Action='left'|'right'|'jump'|'attack';
export interface Settings { music:number; sound:number; muted:boolean; shake:boolean; economy:boolean; touchSize:number; keys:Record<Action,string[]>; }
export interface SaveData {schema:1; updatedAt:string; cards:string[]; stamps:LevelId[]; settings:Settings;}
interface StoragePort {getItem(key:string):string|null;setItem(key:string,value:string):void;removeItem(key:string):void;}
export const DEFAULT_SETTINGS:Settings={music:0.25,sound:0.55,muted:false,shake:true,economy:false,touchSize:1,keys:{left:['ArrowLeft','KeyA'],right:['ArrowRight','KeyD'],jump:['Space'],attack:['KeyJ','KeyZ']}};
const fresh=():SaveData=>({schema:1,updatedAt:new Date().toISOString(),cards:[],stamps:[],settings:structuredClone(DEFAULT_SETTINGS)});
const isRecord=(x:unknown):x is Record<string,unknown>=>!!x&&typeof x==='object'&&!Array.isArray(x);
function parse(raw:string):SaveData {
 const x:unknown=JSON.parse(raw);
 if(!isRecord(x)||x.schema!==1||!Array.isArray(x.cards)||!Array.isArray(x.stamps)||!isRecord(x.settings))throw Error('Invalid save');
 if(!x.cards.every(v=>typeof v==='string'&&ALL_CARD_IDS.has(v))||!x.stamps.every(v=>typeof v==='string'&&LEVEL_IDS.has(v as LevelId)))throw Error('Unknown content');
 const s=x.settings;
 for(const k of ['music','sound'])if(typeof s[k]!=='number'||!Number.isFinite(s[k])||s[k]<0||s[k]>1)throw Error('Invalid volume');
 for(const k of ['muted','shake','economy'])if(typeof s[k]!=='boolean')throw Error('Invalid setting');
 if(typeof s.touchSize!=='number'||s.touchSize<0.8||s.touchSize>1.4||!isRecord(s.keys))throw Error('Invalid controls');
 const used=new Set<string>();
 for(const a of ['left','right','jump','attack']){
   const codes=s.keys[a];
   if(!Array.isArray(codes)||codes.length<1||codes.length>3||!codes.every(c=>typeof c==='string'&&/^(Key[A-Z]|Digit[0-9]|Arrow(Left|Right|Up|Down)|Space)$/.test(c)))throw Error('Invalid binding');
   for(const c of codes){if(used.has(c))throw Error('Conflicting binding');used.add(c);}
 }
 const data=fresh(); data.cards=[...new Set(x.cards as string[])];data.stamps=[...new Set(x.stamps as LevelId[])];data.settings=s as unknown as Settings;
 return data;
}
export class SaveStore{
 data:SaveData=fresh();available=true; reason=''; private writable=true;
 constructor(private port?:StoragePort){
  if(!port){this.fail('目前無法保存進度');return;}
  try{const raw=port.getItem(SAVE_KEY);if(raw)this.data=parse(raw);}catch{
   this.writable=false;this.fail('目前無法讀取進度；原有資料未被覆寫。可在設定中重設。');
  }
 }
 private fail(message:string){this.available=false;this.reason=message;}
 private persist(){
  this.data.updatedAt=new Date().toISOString();
  if(!this.port||!this.writable)return;
  try{this.port.setItem(SAVE_KEY,JSON.stringify(this.data));this.available=true;this.reason='';}
  catch{this.fail('目前無法保存進度；仍可繼續遊玩，本次進度可能不會保留。');}
 }
 collect(id:string){if(!ALL_CARD_IDS.has(id)||this.data.cards.includes(id))return;this.data.cards.push(id);this.persist();}
 complete(id:LevelId){if(!LEVEL_IDS.has(id)||this.data.stamps.includes(id))return;this.data.stamps.push(id);this.persist();}
 updateSettings(patch:Partial<Settings>){
  const candidate={...this.data,settings:{...this.data.settings,...patch}};
  this.data=parse(JSON.stringify(candidate));this.persist();
 }
 reset(){this.data=fresh();this.writable=true;try{this.port?.removeItem(SAVE_KEY);}catch{this.fail('目前無法清除進度');}this.persist();}
}

