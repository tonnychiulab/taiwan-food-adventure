import Phaser from 'phaser';
import { type Level } from './content';
import { Controls } from './input';
import { AudioBus } from './audio';
import { SaveStore } from './storage';

const WIDTH=960,HEIGHT=450,CHUNK=1200,LENGTH=CHUNK*12,GROUND=390;
const MAX_SHOTS=20;
type ArcadeSprite=Phaser.Physics.Arcade.Sprite;
interface Enemy {sprite:ArcadeSprite;kind:number;home:number;hp:number;nextShot:number;stunUntil:number;knockbackUntil:number;boss?:boolean;phase?:number;}
interface Shot {sprite:ArcadeSprite;until:number;friendly:boolean;damage:number;stun:number;}
export interface Hud {hp:number;x:number;checkpoint:number;segment:string;cards:number;fps:number;bossHp:number;bossMax:number;}
export interface GameBridge {store:SaveStore;controls:Controls;audio:AudioBus;hud:(h:Hud)=>void;toast:(message:string)=>void;finish:()=>void;failed:()=>void;}

export class AdventureScene extends Phaser.Scene {
 loadFailed=false; private segmentIndex=-1;
 level!:Level; bridge!:GameBridge; player!:ArcadeSprite;
 private platforms!:Phaser.Physics.Arcade.StaticGroup;
 private enemyGroup!:Phaser.Physics.Arcade.Group;
 private shots:Shot[]=[]; private enemies:Enemy[]=[];
 private pickups!:Phaser.Physics.Arcade.StaticGroup;
 private checkpoints!:Phaser.Physics.Arcade.StaticGroup;
 private bg!:Phaser.GameObjects.TileSprite;
 private weaponDisplay!:Phaser.GameObjects.Sprite;
 private flag!:Phaser.GameObjects.Sprite;
 private hp=3;private facing=1;private checkpoint=80;private invulnerableUntil=0;
 private coyoteUntil=0;private bufferedUntil=0;private attackUntil=0;private hudUntil=0;
 private completed=false;private boss:Enemy|undefined;private bossText!:Phaser.GameObjects.Text;
 private elapsedMs=0;private resetPending=false;
 constructor(){super('adventure');}
 init(data:{level:Level;bridge:GameBridge}){this.level=data.level;this.bridge=data.bridge;this.shots=[];this.enemies=[];this.hp=3;this.facing=1;this.checkpoint=80;this.invulnerableUntil=0;this.coyoteUntil=0;this.bufferedUntil=0;this.attackUntil=0;this.hudUntil=0;this.completed=false;this.boss=undefined;this.elapsedMs=0;this.resetPending=false;this.loadFailed=false;this.segmentIndex=-1;}
 preload(){
  const base=import.meta.env.BASE_URL+'art/';
  this.load.off('loaderror',this.onLoadError,this);
  const sheets:[string,string,number,number][]=[['traveler','traveler.png',24,32],['boss','boss.png',48,48],['foods','foods.png',16,16],['icons','icons.png',20,20]];
  for(let k=0;k<3;k++)sheets.push(['enemy-'+k,'enemy-'+k+'.png',24,24]);
  for(const [key,file,frameWidth,frameHeight] of sheets)if(!this.textures.exists(key))this.load.spritesheet(key,base+file,{frameWidth,frameHeight});
  if(!this.textures.exists('tile'))this.load.image('tile',base+'tile.png');
  for(let part=0;part<3;part++){const key='back-'+this.level.index+'-'+part;if(!this.textures.exists(key))this.load.image(key,base+'background-'+this.level.index+'-section-'+part+'.png');}
  this.load.on('loaderror',this.onLoadError,this);
 }
 private onLoadError(){this.loadFailed=true;this.bridge.failed();}
 create(){
  if(this.loadFailed)return;
  this.load.off('loaderror',this.onLoadError,this);
  this.physics.world.setBounds(0,-100,LENGTH,HEIGHT+300);
  this.physics.world.setFPS(60);
  this.cameras.main.setBounds(0,0,LENGTH,HEIGHT);
  this.bg=this.add.tileSprite(0,0,WIDTH,HEIGHT,'back-'+this.level.index+'-0').setOrigin(0).setScrollFactor(0);
  this.platforms=this.physics.add.staticGroup();this.pickups=this.physics.add.staticGroup();this.checkpoints=this.physics.add.staticGroup();
  this.enemyGroup=this.physics.add.group({allowGravity:true});
  for(let i=0;i<12;i++){
   const x=i*CHUNK;
   this.platform(x,GROUND,850,60);this.platform(x+970,GROUND,230,60);
   this.platform(x+290,315,140,22);this.platform(x+495,257,145,22);
   this.platform(x+1020,314,110,22);
   this.add.text(x+100,365,i%4===0?'旅行補給站':'',{fontFamily:'sans-serif',fontSize:'13px',color:'#31534a'});
   if([2,6,10].includes(i)){
    const card=this.pickups.create(x+567,223,'icons',0) as Phaser.Physics.Arcade.Sprite;
    card.setScale(1.7);card.refreshBody();card.setData('card',this.level.cards[[2,6,10].indexOf(i)].id);
    if(this.bridge.store.data.cards.includes(card.getData('card')))card.setAlpha(.45);
    this.tweens.add({targets:card,y:216,duration:700,yoyo:true,repeat:-1,ease:'Sine.easeInOut'});
   }
   if(i===4||i===8){
    const point=this.checkpoints.create(x+85,369,'icons',2) as Phaser.Physics.Arcade.Sprite;point.setScale(2).refreshBody();point.setData('spawn',x+85);
   }
   if(i>0){this.makeEnemy(x+360,295,i%3);this.makeEnemy(x+1030,360,(i+1)%3);}
   if(i>3&&i%2===0)this.makeEnemy(x+680,360,0);
  }
  if(!this.anims.exists('walk')){this.anims.create({key:'walk',frames:this.anims.generateFrameNumbers('traveler',{frames:[0,1,2,3]}),frameRate:10,repeat:-1});}
  this.player=this.physics.add.sprite(80,GROUND-36,'traveler',0).setScale(1.8).setDepth(5);
  this.player.setSize(14,26).setOffset(7,5).setMaxVelocity(220,850);
  this.player.setCollideWorldBounds(true);
  this.physics.add.collider(this.player,this.platforms);
  this.physics.add.collider(this.enemyGroup,this.platforms);
  this.physics.add.overlap(this.player,this.enemyGroup,(_p,e)=>this.hurt(e as ArcadeSprite));
  this.physics.add.overlap(this.player,this.pickups,(_p,item)=>{
   const card=item as ArcadeSprite;const id=card.getData('card') as string;
   if(!this.bridge.store.data.cards.includes(id)){this.bridge.store.collect(id);this.bridge.audio.play('card');const content=this.level.cards.find(c=>c.id===id)!;this.bridge.toast('收集特色卡：'+content.title);}
   card.disableBody(true,true);
  });
  this.physics.add.overlap(this.player,this.checkpoints,(_p,item)=>{
   const point=item as ArcadeSprite;const spawn=point.getData('spawn') as number;
   if(spawn>this.checkpoint){this.checkpoint=spawn;this.hp=3;this.bridge.audio.play('checkpoint');this.bridge.toast('檢查點已記錄，生命恢復！');point.setTint(0xf4c574);}
  });
  this.weaponDisplay=this.add.sprite(this.player.x,this.player.y,'foods',this.level.index).setScale(2).setDepth(6);
  this.flag=this.add.sprite(LENGTH-130,350,'icons',2).setScale(3);
  this.add.text(LENGTH-220,290,'旅行印章',{fontFamily:'sans-serif',fontSize:'18px',color:'#173d39'});
  if(this.level.id==='magong'){
   this.boss=this.makeEnemy(LENGTH-500,GROUND-55,3,true);
   this.bossText=this.add.text(LENGTH-850,205,'印章怪物正在守候…',{fontFamily:'sans-serif',fontSize:'16px',color:'#173d39'});
  }
  for(let i=0;i<MAX_SHOTS;i++){
   const sprite=this.physics.add.sprite(-100,-100,'foods',0).setScale(1.7).setDepth(4);
   sprite.disableBody(true,true);this.shots.push({sprite,until:0,friendly:true,damage:1,stun:0});
   this.physics.add.overlap(sprite,this.enemyGroup,(_s,e)=>this.hitEnemy(sprite,e as ArcadeSprite));
   this.physics.add.overlap(sprite,this.player,()=>{const shot=this.shots.find(s=>s.sprite===sprite)!;if(!shot.friendly&&sprite.active){sprite.disableBody(true,true);this.hurt();}});
   this.physics.add.collider(sprite,this.platforms,()=>sprite.disableBody(true,true));
  }
  this.cameras.main.startFollow(this.player,true,.1,.1,-180,0);
  this.bridge.controls.clear();this.bridge.controls.enabled=true;this.bridge.audio.startMusic(this.level.index);
  this.events.once('shutdown',()=>{this.bridge.controls.clear();this.bridge.controls.enabled=false;this.bridge.audio.stopMusic();this.load.off('loaderror',this.onLoadError,this);this.enemies=[];this.shots=[];});
  this.bridge.toast('左右移動 · 跳躍 · '+this.level.weaponName+'攻擊。高處藏著特色卡！');
 }
 private platform(x:number,y:number,w:number,h:number){
  const tile=this.add.tileSprite(x,y,w,h,'tile').setOrigin(0);
  this.physics.add.existing(tile,true);this.platforms.add(tile);
 }
 private makeEnemy(x:number,y:number,kind:number,boss=false):Enemy{
  const sprite=this.enemyGroup.create(x,y,boss?'boss':'enemy-'+kind,0) as ArcadeSprite;
  sprite.setScale(boss?2.3:1.7).setSize(boss?38:18,boss?39:20).setOffset(boss?5:3,boss?8:3);
  const body=sprite.body as Phaser.Physics.Arcade.Body;
  if(kind===2)body.setAllowGravity(false);
  const enemy:Enemy={sprite,kind,home:x,hp:boss?12:2,nextShot:0,stunUntil:0,knockbackUntil:0,boss,phase:0};this.enemies.push(enemy);return enemy;
 }
 private spawnShot(x:number,y:number,vx:number,vy:number,friendly:boolean,frame:number,duration:number,stun=0){
  const shot=this.shots.find(s=>!s.sprite.active);if(!shot)return;
  shot.sprite.enableBody(true,x,y,true,true);shot.sprite.setFrame(frame).setScale(friendly&&this.level.weapon==='tofu'?2.4:1.7).clearTint();
  shot.sprite.setSize(12,12).setOffset(2,2);
  const body=shot.sprite.body as Phaser.Physics.Arcade.Body;
  body.setAllowGravity(frame===1);body.setGravityY(frame===1?-420:0);body.setVelocity(vx,vy);
  if(!friendly)shot.sprite.setTint(0x937b9d);
  shot.until=this.elapsedMs+duration;shot.friendly=friendly;shot.damage=1;shot.stun=stun;
 }
 private hitEnemy(sprite:ArcadeSprite,target:ArcadeSprite){
  const shot=this.shots.find(s=>s.sprite===sprite);if(!shot||!shot.friendly||!sprite.active)return;
  const enemy=this.enemies.find(e=>e.sprite===target);if(!enemy||!target.active||enemy.hp<=0)return;
  sprite.disableBody(true,true);this.damageEnemy(enemy,shot.damage,shot.stun);
 }
 private damageEnemy(enemy:Enemy,damage:number,stun=0){
  if(!enemy.sprite.active||enemy.hp<=0)return;
  enemy.hp-=damage;enemy.stunUntil=this.elapsedMs+stun;
  enemy.sprite.setTint(0xffddb3);enemy.sprite.setVelocityX(this.facing*175);enemy.knockbackUntil=this.elapsedMs+220;
  this.time.delayedCall(110,()=>{if(enemy.sprite.active)enemy.sprite.clearTint();});
  if(enemy.hp<=0){enemy.sprite.disableBody(true,true);if(enemy.boss){this.bossText.setText('印章找回來了！');this.bridge.toast('頭目逃跑了！走向旗幟取得印章。');this.bridge.audio.play('stamp');}}
 }
 private attack(){
  const now=this.elapsedMs;if(now<this.attackUntil)return;
  this.attackUntil=now+(this.level.weapon==='egg'?440:380);this.bridge.audio.play('attack');
  this.player.anims.stop();this.player.setFrame(4);
  if(this.level.weapon==='cake'){
   for(const enemy of this.enemies){
    if(!enemy.sprite.active)continue;
    const dx=enemy.sprite.x-this.player.x;
    if(Math.abs(dx)<100&&Math.abs(enemy.sprite.y-this.player.y)<75&&dx*this.facing>-12)this.damageEnemy(enemy,2);
   }
   this.weaponDisplay.setScale(3.4);this.weaponDisplay.setRotation(this.facing*.7);
  }else if(this.level.weapon==='egg'){
   this.spawnShot(this.player.x+this.facing*28,this.player.y+8,this.facing*430,-190,true,1,1400);
  }else{
   this.spawnShot(this.player.x+this.facing*28,this.player.y,this.facing*290,0,true,0,370,420);
  }
 }
 private hurt(enemy?:ArcadeSprite){
  if(this.elapsedMs<this.invulnerableUntil||this.completed||this.resetPending)return;
  this.hp--;this.invulnerableUntil=this.elapsedMs+1500;this.bridge.audio.play('hit');
  if(this.bridge.store.data.settings.shake)this.cameras.main.shake(100,.003);
  const dir=enemy?(this.player.x<enemy.x?-1:1):-this.facing;
  this.player.setVelocity(dir*200,-250);
  if(this.hp<=0){this.resetPending=true;this.bridge.toast('休息一下，從檢查點再出發！');this.time.delayedCall(250,()=>this.respawn());}
 }
 private respawn(){
  this.hp=3;this.resetPending=false;this.invulnerableUntil=this.elapsedMs+1700;
  this.player.setPosition(this.checkpoint,GROUND-40).setVelocity(0,0);
  this.coyoteUntil=0;this.bufferedUntil=0;this.bridge.controls.clear();
  for(const shot of this.shots)shot.sprite.disableBody(true,true);
 }
 update(_time:number,delta:number){
  if(this.loadFailed||!this.player||this.completed)return;
  this.elapsedMs+=Math.min(delta,50);
  const now=this.elapsedMs;const input=this.bridge.controls;
  const body=this.player.body as Phaser.Physics.Arcade.Body;
  const ground=body.blocked.down||body.touching.down;
  if(ground)this.coyoteUntil=now+105;
  if(input.jumpPressed())this.bufferedUntil=now+130;
  if(this.bufferedUntil>=now&&this.coyoteUntil>=now&&!this.resetPending){this.player.setVelocityY(-535);this.bufferedUntil=0;this.coyoteUntil=0;this.bridge.audio.play('jump');}
  const direction=Number(input.held('right'))-Number(input.held('left'));
  if(!this.resetPending)this.player.setVelocityX(direction*185);
  if(direction)this.facing=direction;
  this.player.setFlipX(this.facing<0);
  if(input.held('attack')&&!this.resetPending)this.attack();
  if(now>this.attackUntil-210){
   this.weaponDisplay.setScale(2).setRotation(0);
   if(!ground){this.player.anims.stop();this.player.setFrame(2);}
   else if(direction)this.player.play('walk',true);
   else{this.player.anims.stop();this.player.setFrame(0);}
  }
  if(now<this.invulnerableUntil&&this.invulnerableUntil-now>1280){this.player.anims.stop();this.player.setFrame(5);}
  this.player.setAlpha(now<this.invulnerableUntil&&Math.floor(now/90)%2===0?.4:1);
  this.weaponDisplay.setPosition(this.player.x+this.facing*22,this.player.y+8).setFlipX(this.facing<0);
  this.bg.tilePositionX=this.cameras.main.scrollX*(this.bridge.store.data.settings.economy?0:.18);
  if(this.player.y>HEIGHT+70){this.bridge.audio.play('hit');this.respawn();this.bridge.toast('再試一次！回到最近的檢查點。');}
  for(const enemy of this.enemies){
   const e=enemy.sprite;const b=e.body as Phaser.Physics.Arcade.Body;if(enemy.hp<=0)continue;
   const near=Math.abs(e.x-this.player.x)<900;b.enable=near;if(!near)continue;
   if(e.y>HEIGHT+90){e.setPosition(enemy.home,GROUND-32).setVelocity(0,0);}
   if(now<enemy.knockbackUntil)continue;
   if(now<enemy.stunUntil){e.setVelocityX(0);continue;}
   if(enemy.boss){
    const towards=this.player.x>e.x?1:-1;e.setVelocityX(Math.abs(this.player.x-e.x)>95?towards*48:0);
    if(now>enemy.nextShot){
     enemy.nextShot=now+2600;enemy.phase=(enemy.phase??0)+1;
     this.bossText.setText(enemy.phase%2?'注意！頭目準備投射':'注意！頭目準備跳躍');
     e.setTint(0xf0bc7a);
     const phase=enemy.phase;
     this.time.delayedCall(650,()=>{
      if(enemy.hp<=0||!e.active)return;e.clearTint();
      const sign=this.player.x>e.x?1:-1;
      if(phase%2)this.spawnShot(e.x+sign*65,e.y,sign*270,0,false,0,2400);
      else if(b.blocked.down||b.touching.down){e.setVelocityY(-300);this.spawnShot(e.x,e.y,sign*180,-160,false,1,2400);}
     });
    }
   }else if(enemy.kind===0){
    const vx=e.body?.velocity.x||70;if(e.x>enemy.home+100)e.setVelocityX(-70);else if(e.x<enemy.home-100)e.setVelocityX(70);else e.setVelocityX(vx>0?70:-70);
   }else if(enemy.kind===1){
    e.setVelocityX(0);
    if(now>enemy.nextShot&&Math.abs(e.x-this.player.x)<600){enemy.nextShot=now+2200;const sign=this.player.x>e.x?1:-1;this.spawnShot(e.x+sign*24,e.y-8,sign*215,0,false,0,2100);}
   }else{e.y=290+Math.sin(now/480+enemy.home)*35;e.setVelocityX(this.player.x>e.x?40:-40);}
   e.setFlipX((e.body?.velocity.x??0)<0);
  }
  for(const shot of this.shots)if(shot.sprite.active&&(now>shot.until||Math.abs(shot.sprite.x-this.player.x)>1100||shot.sprite.y>HEIGHT+40))shot.sprite.disableBody(true,true);
  if(this.player.x>LENGTH-175&&(!this.boss||this.boss.hp<=0)){this.completed=true;this.bridge.store.complete(this.level.id);this.bridge.audio.play('stamp');this.bridge.controls.clear();this.bridge.controls.enabled=false;this.bridge.audio.stopMusic();this.player.setVelocity(0,0);this.bridge.finish();}
  const segment=Math.min(2,Math.floor(this.player.x/(LENGTH/3)));
  if(segment!==this.segmentIndex){this.bg.setTexture('back-'+this.level.index+'-'+segment);if(this.segmentIndex>=0){this.cameras.main.flash(400,246,243,222);this.bridge.toast('旅行轉場：'+this.level.sceneNames[segment]+'（非相鄰街道）');}this.segmentIndex=segment;}
  if(now>this.hudUntil){this.hudUntil=now+100;this.bridge.hud({hp:this.hp,x:this.player.x,checkpoint:this.checkpoint,segment:this.level.sceneNames[Math.min(2,Math.floor(this.player.x/(LENGTH/3)))],cards:this.level.cards.filter(c=>this.bridge.store.data.cards.includes(c.id)).length,fps:this.game.loop.actualFps,bossHp:this.boss?.hp??0,bossMax:12});}
 }
 pauseGame(){this.bridge.controls.enabled=false;this.bridge.controls.clear();this.bridge.audio.stopMusic();this.scene.pause();}
 resumeGame(){this.bridge.controls.clear();this.bridge.controls.enabled=true;this.bridge.audio.startMusic(this.level.index);this.scene.resume();}
}

export function createGame(parent:string){
 return new Phaser.Game({type:Phaser.AUTO,parent,width:WIDTH,height:HEIGHT,backgroundColor:'#e9eadc',pixelArt:true,roundPixels:true,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},physics:{default:'arcade',arcade:{gravity:{x:0,y:1150},debug:false,fixedStep:true,fps:60}},fps:{target:60,forceSetTimeOut:false,smoothStep:true},scene:[],audio:{noAudio:true}});
}
