import Phaser from 'phaser';
import './style.css';
import {LEVELS,UPCOMING,ISLANDS,VERSION,type Level} from './content';
import {SaveStore,DEFAULT_SETTINGS,type Action} from './storage';
import {Controls} from './input';
import {AudioBus} from './audio';
import {AdventureScene,createGame,type Hud,type GameBridge} from './game';

const app=document.querySelector<HTMLDivElement>('#app')!;
let storage:Storage|undefined;try{storage=window.localStorage;}catch{/* private browsing or policy */}
const store=new SaveStore(storage),controls=new Controls(()=>store.data.settings),audio=new AudioBus(()=>store.data.settings);
let game:Phaser.Game|undefined,scene:AdventureScene|undefined,current:Level|undefined;
let startGeneration=0;
let pendingCreate:(()=>void)|null=null;
let playing=false,paused=false,tutorialSeen=false,returnView='home',overlayOrigin:HTMLElement|null=null,loaded=false,finished=false;
const art=(name:string)=>import.meta.env.BASE_URL+'art/'+name;
const escape=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const foodIcon=(index:number)=>`<span class="food-icon food-${index}" aria-hidden="true"></span>`;
const keyName=(code:string)=>code==='Space'?'空白鍵':code.replace('Key','').replace('Digit','').replace('ArrowLeft','←').replace('ArrowRight','→').replace('ArrowUp','↑').replace('ArrowDown','↓');
app.innerHTML=`
 <header class="site-header"><button class="brand" data-view="home" aria-label="返回首頁"><span class="brand-icon">旅</span><span>環島護照<small>台灣小吃冒險</small></span></button><nav aria-label="主要導覽"><button data-view="map">旅行地圖</button><button data-view="passport">我的護照 <span id="nav-count">0 / 3</span></button><button data-view="settings" aria-label="設定">設定</button></nav><span class="version">v${VERSION} 試玩版</span></header>
 <main id="menu"></main>
 <section id="play" class="play-view hidden" aria-label="遊戲區域">
  <div class="game-top"><button data-action="leave" class="quiet">← 旅行地圖</button><div><b id="level-name"></b><span id="segment"></span></div><button data-action="pause" class="pause-button">Ⅱ 暫停</button></div>
  <div class="stage-wrap"><div id="stage"></div><div class="hud"><div><span id="hearts" aria-label="生命">♥ ♥ ♥</span><span id="weapon-hud"></span></div><div><span id="card-hud">特色卡 0 / 3</span><span id="progress-hud">出發！</span></div></div>
   <div id="boss-hud" class="boss-hud hidden"><span>印章怪物</span><progress max="12" value="12"></progress></div>
   <div id="toast" class="toast" role="status"></div>
   <div class="touch-controls"><div class="touch-move"><button class="touch" data-touch="left" aria-label="向左">◀</button><button class="touch" data-touch="right" aria-label="向右">▶</button></div><div class="touch-actions"><button class="touch jump" data-touch="jump" aria-label="跳躍">跳躍</button><button class="touch attack" data-touch="attack" aria-label="攻擊">攻擊</button></div></div>
  </div>
  <div class="game-bottom"><span id="hint">← → 移動 · 空白鍵跳躍 · J / Z 攻擊</span><span id="save-status"></span></div>
 </section>
 <div id="overlay" class="overlay hidden" role="dialog" aria-modal="true" aria-label="遊戲選單"></div>
 <footer><span>像素裡的台灣，等你慢慢發現。</span><span>製作團隊：<a href="https://joyyoung.ai/" target="_blank" rel="noopener">中揚資訊</a> · <button data-view="about">關於與素材授權</button></span></footer>
`;
const menu=document.querySelector<HTMLElement>('#menu')!,play=document.querySelector<HTMLElement>('#play')!,overlay=document.querySelector<HTMLElement>('#overlay')!;
document.querySelectorAll<HTMLElement>('[data-touch]').forEach(b=>controls.bindTouch(b,b.dataset.touch as Action));
controls.onPause=()=>pause();
let toastTimeout:number|undefined;
function toast(message:string){const t=document.querySelector<HTMLElement>('#toast')!;t.textContent=message;t.classList.add('visible');clearTimeout(toastTimeout);toastTimeout=window.setTimeout(()=>t.classList.remove('visible'),3500);}
function sync(){
 document.querySelector('#nav-count')!.textContent=store.data.stamps.length+' / 3';
 document.querySelector('#save-status')!.textContent=store.available?'進度保存在此瀏覽器':store.reason;
 document.documentElement.style.setProperty('--touch-size',String(store.data.settings.touchSize));
}
function islandMap(){return `<svg class="island-map" viewBox="0 0 400 420" role="img" aria-label="台灣旅行地圖，第一版開放萬華、瑞芳與馬公"><defs><pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0V24" fill="none" stroke="#719488" stroke-opacity=".15"/></pattern></defs><rect width="400" height="420" rx="22" fill="#e7ecdf"/><rect width="400" height="420" fill="url(#grid)"/><path d="M263 42h36v24h20v48h-14v40h-18v48h-18v42h-20v48h-21v42h-24v42h-20v-15h-15v-54h14v-52h17v-50h16v-44h17v-45h17V76h13z" fill="#7e9d75"/><path d="M263 66h21v55h-17v44h-16v46h-17v44h-17v38h-14v-24h10v-48h17v-49h16v-49h17z" fill="#aec08a"/><path d="M264 78L281 90 109 248" stroke="#e69658" stroke-width="3" fill="none" stroke-dasharray="5 7"/><g fill="#54796a"><rect x="84" y="228" width="20" height="19"/><rect x="103" y="252" width="13" height="13"/><rect x="74" y="256" width="12" height="11"/><rect x="41" y="131" width="16" height="13"/><rect x="55" y="65" width="12" height="11"/></g><g fill="#f4ca7a" stroke="#173d39" stroke-width="3"><circle cx="265" cy="78" r="7"/><circle cx="284" cy="91" r="7"/><circle cx="105" cy="240" r="7"/></g><g font-family="sans-serif" font-weight="700" font-size="15" fill="#173d39"><text x="178" y="69">萬華</text><text x="302" y="96">瑞芳</text><text x="117" y="248">馬公</text></g><g font-family="sans-serif" font-size="11" fill="#608478"><text x="23" y="154">金門</text><text x="38" y="56">馬祖</text><text x="268" y="329">綠島 · 蘭嶼</text><text x="149" y="362">小琉球</text><text x="24" y="400">示意地圖 · 不作導航使用</text></g></svg>`;}
function levelCard(l:Level){return `<button class="region-card" data-start="${l.id}" aria-label="前往${l.name}"><div class="region-art"><img src="${art('background-'+l.index+'.png')}" alt="" loading="lazy"><span class="region-tag">0${l.index+1} / ${l.index===2?'離島':'本島'}</span>${foodIcon(l.index)}</div><div class="region-copy"><span class="overline">${l.subtitle}</span><div><h3>${l.name}</h3><span class="arrow">↗</span></div><p>${l.weaponName}裝備 · 約 3–5 分鐘</p><div class="region-bottom"><span>${store.data.stamps.includes(l.id)?'✓ 印章已取得':'等你來蓋章'}</span><span>特色卡 ${l.cards.filter(c=>store.data.cards.includes(c.id)).length}/3</span></div></div></button>`;}
function heading(kicker:string,title:string,description:string){return `<div class="page-heading"><span class="overline">${kicker}</span><h1>${title}</h1><p>${description}</p></div>`;}
function showView(view:string){
 if(playing){if(view==='settings'||view==='about'||view==='passport'){pause();showOverlayPage(view);return;}if(!confirm('返回地圖會結束本次關卡，已取得收藏會保留。'))return;stop();}
 returnView=view;menu.classList.remove('hidden');play.classList.add('hidden');document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',(el as HTMLElement).dataset.view===view));
 if(view==='home'){
 menu.innerHTML=`<section class="hero"><div class="hero-copy"><span class="eyebrow"><i></i> 一口小吃，一段旅行</span><h1>一路玩，<br>一路認識<span>台灣。</span></h1><p>帶上臭豆腐、皮蛋與豬血糕。<br>跟著小旅穿過街屋、山城和海風，<br>把每個地方的故事收進你的旅行護照。</p><button class="primary" data-view="map">出發，選個地方 <span>↗</span></button><div class="hero-notes"><span>免登入</span><span>手機 · 電腦都能玩</span><span>免費試玩</span></div></div><div class="hero-map">${islandMap()}<div class="map-badge"><span class="pixel-traveler"></span><div><b>小旅的第一站</b><span>3 個地方 · 9 張特色卡</span></div></div></div></section><section class="region-section"><div class="section-head"><div><span class="overline">第一趟旅行</span><h2>今天，想去哪裡？</h2></div><span>本島到離島，都有故事。</span></div><div class="regions">${LEVELS.map(levelCard).join('')}</div></section><section class="passport-strip"><span class="strip-icon">旅</span><div><h3>留下印章，也帶走故事。</h3><p>找到藏在關卡裡的特色卡，認識下一趟旅行的目的地。</p></div><button data-view="passport">打開我的護照 →</button></section>`;
 }else if(view==='map'){
 menu.innerHTML=heading('選一站，開始冒險','你的環島路線','三個地方自由選，第一次玩推薦從萬華出發。')+`<div class="map-layout"><div class="map-side">${islandMap()}<p>關卡採地方取景，並非真實街道路線。</p></div><div class="map-regions">${LEVELS.map(levelCard).join('')}</div></div><section class="upcoming"><h2>旅行還會繼續</h2><p>全台與離島是後續擴充方向，以下地區尚未開放遊戲關卡。</p><div>${[...UPCOMING,...ISLANDS].map(n=>`<span>${n}<small>尚未開放</small></span>`).join('')}</div><p class="muted">縣市、鄉鎮區與島嶼將分層整理；這裡先列出後續旅行方向。</p></section>`;
 }else if(view==='passport')menu.innerHTML=passport();
 else if(view==='settings')menu.innerHTML=heading('讓旅途更舒服','遊戲設定','設定與進度保存在目前的瀏覽器。')+settings();
 else menu.innerHTML=about();
 bindSettings();sync();window.scrollTo({top:0,behavior:'instant'});
}
function passport(){return heading('每一枚印章，都有一段故事','我的旅行護照',`已取得 ${store.data.stamps.length}/3 枚印章、${store.data.cards.length}/9 張特色卡。`)+`<div class="stamps">${LEVELS.map(l=>`<div class="stamp ${store.data.stamps.includes(l.id)?'earned':''}"><span>環島護照</span><b>${l.name}</b><small>${store.data.stamps.includes(l.id)?'旅行完成':'等待你的足跡'}</small></div>`).join('')}</div><div class="passport-groups">${LEVELS.map(l=>`<section><h2>${l.name}<small>${l.subtitle}</small></h2><div class="collection-cards">${l.cards.map(c=>`<article class="collection ${store.data.cards.includes(c.id)?'found':''}"><span class="overline">${store.data.cards.includes(c.id)?'✓ 已收藏':'尚未發現'}</span><h3>${store.data.cards.includes(c.id)?c.title:'神祕的地方故事'}</h3><p>${store.data.cards.includes(c.id)?c.text:'在關卡的高處找找看。收藏不影響通關，可以慢慢探索。'}</p>${store.data.cards.includes(c.id)?`<a href="${c.url}" target="_blank" rel="noopener">官方旅遊資訊 ↗</a>`:`<button data-start="${l.id}">前往${l.name} →</button>`}</article>`).join('')}</div></section>`).join('')}</div><p class="save-note">進度依網站分開保存。Cloudflare 與 GitHub Pages 網址的進度不會自動同步；換裝置或清除網站資料也可能失去進度。</p>`;}
function settings(){const s=store.data.settings;return `<div class="settings-panel"><div class="setting-row"><label for="music">背景音樂</label><input id="music" data-setting="music" type="range" min="0" max="1" step=".05" value="${s.music}"></div><div class="setting-row"><label for="sound">音效</label><input id="sound" data-setting="sound" type="range" min="0" max="1" step=".05" value="${s.sound}"></div>${[['muted','全部靜音'],['shake','畫面震動'],['economy','省效能模式（減少背景移動）']].map(([key,label])=>`<div class="setting-row"><label for="${key}">${label}</label><input type="checkbox" id="${key}" data-setting="${key}" ${s[key as 'muted']?'checked':''}></div>`).join('')}<div class="setting-row"><label for="touchSize">手機按鈕大小</label><input type="range" id="touchSize" data-setting="touchSize" min=".8" max="1.4" step=".1" value="${s.touchSize}"></div><div class="key-settings"><h3>鍵盤操作</h3><p>點選動作，再按要使用的按鍵。Esc 取消設定。</p>${(['left','right','jump','attack'] as Action[]).map((action,i)=>`<button class="binding" data-bind="${action}"><span>${['向左','向右','跳躍','攻擊'][i]}</span><kbd>${s.keys[action].map(keyName).join(' / ')}</kbd></button>`).join('')}<button data-action="reset-keys" class="quiet">恢復預設按鍵</button><p id="binding-status" role="status"></p></div><div class="danger-zone"><div><b>重設旅行進度</b><p>清除印章、特色卡與設定；操作前會再確認。</p></div><button data-action="reset">重設進度</button></div><p class="save-note">${store.available?'這裡不需要帳號。進度只保存在此網站與此瀏覽器。':escape(store.reason)}</p></div>`;}
function bindSettings(){
 document.querySelectorAll<HTMLInputElement>('[data-setting]').forEach(el=>el.addEventListener('input',()=>{const key=el.dataset.setting!;store.updateSettings({[key]:el.type==='checkbox'?el.checked:Number(el.value)});sync();}));
 document.querySelectorAll<HTMLElement>('[data-bind]').forEach(el=>el.addEventListener('click',()=>{
  const action=el.dataset.bind as Action;const status=document.querySelector('#binding-status')!;status.textContent='請按一個字母、數字、方向鍵或空白鍵；Esc 取消。';
  controls.capture=code=>{
   if(code==='Escape'){controls.capture=null;status.textContent='已取消。';return;}
   if(!/^(Key[A-Z]|Digit[0-9]|Arrow(Left|Right|Up|Down)|Space)$/.test(code)){status.textContent='請使用字母、數字、方向鍵或空白鍵。';return;}
   if(Object.entries(store.data.settings.keys).some(([a,list])=>a!==action&&list.includes(code))){status.textContent='這個按鍵已用於另一個動作，請選其他按鍵。';return;}
   const keys=structuredClone(store.data.settings.keys);keys[action]=[code];store.updateSettings({keys});controls.capture=null;el.querySelector('kbd')!.textContent=keyName(code);status.textContent='按鍵已更新。';sync();
  };
 }));
}
function about(){return heading('小旅的製作手記','關於這趟旅行','台灣小吃冒險：環島護照 · v'+VERSION+' 試玩版')+`<div class="about-panel"><h2>用遊戲，慢慢認識地方。</h2><p>第一版開放萬華、瑞芳與馬公，使用小吃裝備找回旅行印章。場景是地方取景的奇幻創作，不能當作真實導航。</p><h3>製作與授權</h3><p>製作團隊：<a href="https://joyyoung.ai/" target="_blank" rel="noopener">中揚資訊</a>。程式採 MIT；本版原創像素美術與音樂旋律／音效設計採 <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>。未使用馬力歐圖像、音樂或角色。</p><p>圖像由程式繪製成像素素材，沒有使用外部照片或 AI 生成圖像。Phaser 3.90.0 使用 MIT 授權，完整聲明附於下載包。</p><h3>地方資料</h3><p>九份採金與猴硐煤礦分開介紹；馬公不借用其他鄉市地標。已收集特色卡可查看官方資料，查核日期 2026-10-04。</p><h3>進度與隱私</h3><p>遊戲不加入帳號、廣告或玩家追蹤。進度保存在瀏覽器，兩個不同網站網址不會同步；主機平台仍可能保留安全與存取日誌。</p><h3>效能與裝置</h3><p>標準畫質以 60 FPS 為目標。手機需橫向遊玩；可關閉震動、音效與背景移動。實際 Android／iPhone 及五位新手試玩仍需驗收，不能以自動化測試冒充。</p><p class="save-note">作品名称、團隊名稱與標誌不包含在素材再利用授權內。</p></div>`;}
function showOverlay(html:string,label='遊戲選單'){
 overlayOrigin=document.activeElement as HTMLElement;overlay.setAttribute('aria-label',label);overlay.innerHTML=html;overlay.classList.remove('hidden');menu.inert=true;play.inert=true;
 overlay.querySelector<HTMLElement>('button,a,input')?.focus();bindSettings();
}
function closeOverlay(){overlay.classList.add('hidden');overlay.innerHTML='';menu.inert=false;play.inert=false;controls.capture=null;overlayOrigin?.focus();}
function showOverlayPage(view:string){showOverlay(`<div class="dialog large"><button class="dialog-close" data-action="back-pause">← 返回暫停選單</button>${view==='settings'?settings():view==='passport'?passport():about()}</div>`,view==='settings'?'遊戲設定':view==='passport'?'旅行護照':'關於遊戲');}
function pause(){
 if(!playing||paused||!scene)return;paused=true;scene.pauseGame();
 showOverlay(`<div class="dialog pause-dialog"><span class="overline">休息一下，再出發</span><h2>旅行暫停中</h2><p>已取得的特色卡會保留。</p><button class="primary" data-action="resume">繼續冒險 →</button><div class="dialog-links"><button data-view="passport">旅行護照</button><button data-view="settings">設定</button><button data-action="restart">重新開始</button><button data-action="leave">返回地圖</button></div></div>`,'遊戲暫停');
}
function resume(){
 if(!playing||!loaded||!scene)return;
 if(isPortrait()){showRotation();return;}
 closeOverlay();paused=false;void audio.unlock();scene.resumeGame();sync();
}
function stop(){startGeneration++;if(pendingCreate&&scene?.events)scene.events.off('create',pendingCreate);pendingCreate=null;playing=false;paused=false;loaded=false;finished=false;controls.clear();controls.enabled=false;if(game?.scene.getScene('adventure'))game.scene.stop('adventure');audio.stopMusic();closeOverlay();sync();}
function showRotation(){
 if(!playing||!loaded)return;
 if(!paused){paused=true;scene?.pauseGame();}
 showOverlay(`<div class="dialog"><span class="rotate-icon">↻</span><h2>把手機轉橫向</h2><p>橫向能看見更完整的關卡。旋轉後按「繼續冒險」。</p><button data-action="resume" class="primary">繼續冒險 →</button><button data-action="leave" class="quiet">返回旅行地圖</button></div>`,'請將手機轉為橫向');
}
function isPortrait(){return matchMedia('(pointer:coarse)').matches&&innerHeight>innerWidth;}
async function start(level:Level){
 if(playing&&!confirm('切換關卡會結束本次冒險，已取得收藏會保留。'))return;
 if(playing)stop();const request=++startGeneration;current=level;playing=true;paused=false;loaded=false;finished=false;controls.enabled=false;
 menu.classList.add('hidden');play.classList.remove('hidden');closeOverlay();sync();window.scrollTo(0,0);await audio.unlock();if(request!==startGeneration||!playing)return;
 document.querySelector('#level-name')!.textContent=level.name+'冒險';
 document.querySelector('#weapon-hud')!.innerHTML=foodIcon(level.index)+level.weaponName;
 document.querySelector('#boss-hud')!.classList.add('hidden');
 showOverlay(`<div class="dialog"><span class="overline">整理行李中</span><h2>正在前往${level.name}…</h2><p>準備關卡與小吃裝備。</p><button class="quiet" data-action="leave">取消，返回地圖</button></div>`,'正在載入');
 const bridge:GameBridge={store,controls,audio,hud:updateHud,toast,finish,failed:()=>{if(request!==startGeneration)return;loaded=false;controls.enabled=false;audio.stopMusic();showOverlay(`<div class="dialog"><h2>關卡沒有載入完成</h2><p>請確認網路連線後再試一次。</p><button class="primary" data-action="restart">重新載入</button><button data-action="leave">返回地圖</button></div>`,'載入失敗');}};
 const ready=()=>{
  if(!playing||request!==startGeneration)return;
  if(!game!.scene.getScene('adventure'))game!.scene.add('adventure',scene!,false);
  pendingCreate=()=>{if(request!==startGeneration||!playing||scene!.loadFailed)return;pendingCreate=null;loaded=true;closeOverlay();if(!tutorialSeen){tutorialSeen=true;paused=true;scene!.pauseGame();showOverlay(`<div class="dialog tutorial"><span class="overline">小旅的第一課</span><h2>三個動作，就能出發。</h2><div class="tutorial-steps"><p><b>01 移動</b>左右走動，找出前進路線。</p><p><b>02 跳躍</b>跳上平台，高處藏著特色卡。</p><p><b>03 攻擊</b>按住攻擊，使用${level.weaponName}。</p></div><p>三格生命 · 檢查點恢復 · 不限次重試。<br>收藏可以慢慢找，不必全部找到才通關。</p><button class="primary" data-action="resume">開始冒險 →</button><button class="quiet" data-action="resume">略過教學，開始</button></div>`,'操作教學');}else if(isPortrait())showRotation();sync();};scene!.events.once('create',pendingCreate);
  game!.scene.start('adventure',{level,bridge});
 };
 if(!game){game=createGame('stage');scene=new AdventureScene();game.events.once(Phaser.Core.Events.READY,ready);}
 else ready();
}
function updateHud(h:Hud){
 const hearts=document.querySelector('#hearts')!;hearts.textContent=Array.from({length:3},(_,i)=>i<h.hp?'♥':'♡').join(' ');hearts.setAttribute('aria-label','生命 '+h.hp+' / 3');
 document.querySelector('#segment')!.textContent=h.segment;
 document.querySelector('#card-hud')!.textContent='特色卡 '+h.cards+' / 3';
 document.querySelector('#progress-hud')!.textContent='旅程 '+Math.min(100,Math.floor(h.x/14400*100))+'%';
 const boss=document.querySelector('#boss-hud')!;boss.classList.toggle('hidden',!current||current.id!=='magong'||h.x<13100||h.bossHp<=0);boss.querySelector('progress')!.value=h.bossHp;
 play.dataset.x=String(Math.round(h.x));play.dataset.hp=String(h.hp);play.dataset.fps=h.fps.toFixed(1);sync();
 const keys=store.data.settings.keys;document.querySelector('#hint')!.textContent=keys.left.map(keyName).join('/')+' '+keys.right.map(keyName).join('/')+' 移動 · '+keys.jump.map(keyName).join('/')+' 跳躍 · '+keys.attack.map(keyName).join('/')+' 攻擊';
}
function finish(){
 if(!current||!scene)return;finished=true;paused=true;scene.pauseGame();sync();
 showOverlay(`<div class="dialog finish"><span class="overline">又收下一段台灣故事</span><div class="stamp earned"><span>環島護照</span><b>${current.name}</b><small>旅行完成</small></div><h2>印章，收進護照了！</h2><p>這一站找到 ${current.cards.filter(c=>store.data.cards.includes(c.id)).length} / 3 張特色卡。<br>還有故事沒找到？隨時可以再來。</p><button data-view="passport" class="primary">打開旅行護照 →</button><div class="dialog-links"><button data-action="restart">再玩一次</button><button data-action="leave">下一站，出發</button></div></div>`,'關卡完成');
}
app.addEventListener('click',e=>{
 const button=(e.target as HTMLElement).closest<HTMLElement>('[data-view],[data-start],[data-action]');if(!button)return;
 if(button.dataset.start){const level=LEVELS.find(l=>l.id===button.dataset.start);if(level)void start(level);return;}
 if(button.dataset.view){if(playing&&paused&&button.dataset.view==='passport'&&finished){stop();showView('passport');}else showView(button.dataset.view);return;}
 switch(button.dataset.action){
 case 'pause':pause();break;
 case 'resume':resume();break;
 case 'back-pause':closeOverlay();paused=false;pause();break;
 case 'leave':if(playing&&loaded&&!confirm('結束本次關卡並返回地圖？已取得收藏會保留。'))return;stop();showView('map');break;
 case 'restart':if(current){const level=current;stop();void start(level);}break;
 case 'reset-keys':store.updateSettings({keys:structuredClone(DEFAULT_SETTINGS.keys)});controls.capture=null;if(playing)showOverlayPage('settings');else showView('settings');break;
 case 'reset':if(confirm('確定清除所有印章、特色卡與設定？')){store.reset();sync();if(playing){stop();showView('settings');}else showView('settings');}break;
 }
});
overlay.addEventListener('keydown',e=>{
 if(e.key==='Tab'){const elements=Array.from(overlay.querySelectorAll<HTMLElement>('button,a,input'));const first=elements[0],last=elements.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
 if(e.key==='Escape'&&!controls.capture&&playing&&loaded){e.preventDefault();resume();}
});
document.addEventListener('visibilitychange',()=>{if(document.hidden){controls.clear();if(playing&&!paused)pause();}});
window.addEventListener('blur',()=>{if(playing&&!paused&&loaded)pause();});
window.addEventListener('resize',()=>{if(playing&&loaded&&isPortrait())showRotation();});
showView('home');
// Used by local automated validation via module import; no global cheat controls.
export function validationContext(){return {game,scene,store,controls,playing,paused,loaded};}
