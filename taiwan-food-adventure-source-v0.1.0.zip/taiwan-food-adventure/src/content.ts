export type LevelId = 'wanhua' | 'ruifang' | 'magong';
export type Weapon = 'tofu' | 'egg' | 'cake';
export interface Card { id: string; title: string; text: string; url: string; }
export interface Level { id: LevelId; name: string; subtitle: string; weapon: Weapon; weaponName: string; index: number; sceneNames: string[]; cards: Card[]; }
export const VERSION = '0.1.0';
export const LEVELS: Level[] = [
 {id:'wanhua',name:'萬華',subtitle:'臺北市 · 街屋與夜市',weapon:'tofu',weaponName:'臭豆腐',index:0,sceneNames:['艋舺街區','剝皮寮取景','夜市冒險'],cards:[
 {id:'wanhua-temple',title:'艋舺龍山寺',text:'艋舺龍山寺是萬華重要的信仰與文化地標。走近廟埕，可以欣賞臺灣寺廟屋頂與雕刻藝術，也能認識地方民俗活動。遊戲中的寺廟只是背景，想了解實際參觀資訊，請查看官方介紹。',url:'https://whdo.gov.taipei/News_Content.aspx?n=2B790586BA4E1E7A&s=039849E84D5B9C7B&sms=15EB41D4C772E746'},
 {id:'wanhua-street',title:'剝皮寮街屋',text:'剝皮寮保存傳統街型與街屋，紅磚牆、騎樓及窗飾帶出老街的生活記憶。這裡也有不同年代留下的建築面貌。遊戲將街屋化為像素場景，實際散步時可以慢慢觀察細節。',url:'https://whdo.gov.taipei/News_Content.aspx?n=2B790586BA4E1E7A&s=E851BD3F7AA8DBFE&sms=15EB41D4C772E746'},
 {id:'wanhua-food',title:'艋舺夜市小吃',text:'萬華的夜市商圈集合傳統小吃、雜貨與遊戲攤位，是認識在地生活的好地方。廣州街一帶可以找到多樣臺灣小吃。遊戲中的臭豆腐是旅行裝備，並不表示這道食物起源於萬華。',url:'https://whdo.gov.taipei/News_Content.aspx?n=2B790586BA4E1E7A&s=0B2B2409C397BFB7&sms=15EB41D4C772E746'}]},
 {id:'ruifang',name:'瑞芳',subtitle:'新北市 · 山城與礦業',weapon:'egg',weaponName:'皮蛋',index:1,sceneNames:['九份山城取景','九份階梯冒險','猴硐礦業取景'],cards:[
 {id:'ruifang-town',title:'九份山城',text:'九份是依山坡發展的聚落，過去因採金而繁華。階梯、曲折巷弄與茶樓構成山城風景。遊戲壓縮了場景距離，真實旅行時請依官方交通與步行資訊安排，慢慢感受山城節奏。',url:'https://newtaipei.travel/zh-tw/attractions/detail/109990'},
 {id:'ruifang-food',title:'芋圓與草仔粿',text:'逛九份老街，可以認識芋圓、肉圓與草仔粿等經典小食。食物不只是旅行中的補給，也連結地方生活。這一關使用的皮蛋是小旅隨身裝備，不代表九份小吃的起源故事。',url:'https://newtaipei.travel/zh-tw/attractions/detail/109990'},
 {id:'ruifang-mine',title:'猴硐煤礦文化',text:'猴硐保有煤礦產業的歷史線索，可以從運煤設施與礦業展示了解昔日工作生活。猴硐採煤與九份採金是不同故事。兩處都在瑞芳區，遊戲以轉場區分，並非相鄰的一條街。',url:'https://newtaipei.travel/zh-tw/attractions/detail/110748'}]},
 {id:'magong',name:'馬公',subtitle:'澎湖縣 · 老街與海洋',weapon:'cake',weaponName:'豬血糕',index:2,sceneNames:['馬公港口取景','中央老街取景','海洋冒險'],cards:[
 {id:'magong-street',title:'中央老街',text:'中央老街記錄馬公早期的街區發展，傳統商店街與歷史建築帶出地方生活。旅行時可以留意四眼井等街區線索。遊戲的像素老街採取景式設計，不是可以拿來導航的真實地圖。',url:'https://www.taiwan.net.tw/m1.aspx?id=A12-00347&sNo=0001016'},
 {id:'magong-temple',title:'澎湖天后宮',text:'澎湖天后宮位於馬公，是重要的信仰與文化地標。廟宇建築與街區生活互相連結，適合以尊重的態度參觀。遊戲將它作為背景與收藏主題，戰鬥安排在另外的奇幻冒險區域。',url:'https://www.penghu-nsa.gov.tw/TravelInformationSceneryDetailC001200.aspx?Cond=73eae1ff-0b2f-4bfd-b1b3-b37f0c611a31&Language=1028&SearchAdvanced=False'},
 {id:'magong-sea',title:'港口與海洋生活',text:'馬公的港口、船隻與街區，讓旅人看見澎湖海洋生活的一面。離島不只有海灘，也有聚落與人文記憶。遊戲不把西嶼或七美的知名地景當成馬公市景點，旅遊資訊請看官方路線。',url:'https://www.penghu-nsa.gov.tw/ChiHoOneLer/tour/ThematicTours/Theme10/BikeTour01.htm'}]}
];
export const ALL_CARD_IDS = new Set(LEVELS.flatMap(l=>l.cards.map(c=>c.id)));
export const LEVEL_IDS = new Set(LEVELS.map(l=>l.id));
export const ISLANDS = ['金門','馬祖','綠島','蘭嶼','小琉球'];
export const UPCOMING = ['基隆','桃園','新竹','苗栗','臺中','彰化','南投','雲林','嘉義','臺南','高雄','屏東','宜蘭','花蓮','臺東'];

