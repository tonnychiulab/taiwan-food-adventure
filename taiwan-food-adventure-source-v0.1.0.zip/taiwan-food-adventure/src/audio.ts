import type {Settings} from './storage';
type Sound='jump'|'attack'|'hit'|'card'|'stamp'|'checkpoint';
export class AudioBus{
 private ctx:AudioContext|null=null;private timer:number|undefined;private step=0;private voices=0;
 constructor(private settings:()=>Settings){}
 async unlock(){try{this.ctx??=new AudioContext();await this.ctx.resume();}catch{/* visual feedback remains available */}}
 private tone(freq:number,duration:number,volume:number,type:OscillatorType='square',delay=0){
  const ctx=this.ctx;if(!ctx||ctx.state!=='running'||this.voices>=12)return;
  const osc=ctx.createOscillator(),gain=ctx.createGain();const at=ctx.currentTime+delay;
  osc.type=type;osc.frequency.value=freq;gain.gain.setValueAtTime(volume,at);gain.gain.exponentialRampToValueAtTime(.001,at+duration);
  osc.connect(gain);gain.connect(ctx.destination);osc.start(at);osc.stop(at+duration+.02);this.voices++;
  osc.onended=()=>{osc.disconnect();gain.disconnect();this.voices--;};
 }
 play(sound:Sound){
  const s=this.settings();if(s.muted||s.sound===0)return;
  const seq:Record<Sound,number[]>={jump:[330,550],attack:[180,120],hit:[130,70],card:[523,659,784],stamp:[523,659,784,1047],checkpoint:[392,523]};
  seq[sound].forEach((f,i)=>this.tone(f,.11,s.sound*.045,'square',i*.08));
 }
 startMusic(index:number){
  this.stopMusic();this.step=0;
  const melodies=[[262,330,392,330,440,392,330,294],[294,370,440,370,494,440,330,370],[330,392,494,392,523,494,392,294]];
  this.timer=window.setInterval(()=>{const s=this.settings();if(s.muted||s.music===0)return;const notes=melodies[index];this.tone(notes[this.step%notes.length],.22,s.music*.025,'triangle');if(this.step%2===0)this.tone(notes[0]/2,.33,s.music*.02,'sine');this.step++;},260);
 }
 stopMusic(){if(this.timer!==undefined)clearInterval(this.timer);this.timer=undefined;}
 destroy(){this.stopMusic();void this.ctx?.close();}
}

